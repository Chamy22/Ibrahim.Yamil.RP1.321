package baseespacial;

public class MismoNombreYModuloException extends RuntimeException {

    public MismoNombreYModuloException() {
    }

    public MismoNombreYModuloException(String message) {
        super(message);
    }

}
