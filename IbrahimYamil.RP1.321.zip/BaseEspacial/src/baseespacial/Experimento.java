package baseespacial;

public class Experimento extends UnidadOperativa {

    private int duracionIdeal;

    public Experimento(int duracionIdeal, String nombre, String modulo, TipoAtmofera tipoatmofera) {
        super(nombre, modulo, tipoatmofera);
        this.duracionIdeal = duracionIdeal;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());

        sb.append("-duracion Ideal = ").append(duracionIdeal);

        return sb.toString();
    }

    @Override
    public void reabastecerse() {
        System.out.println("El experimento se reabastece.");
    }

    @Override
    public void mantenerCondicionAtmoferica() {
        System.out.println("Experimento mantiene las condiciones atmosfericas.");
    }

    @Override
    public void replicarse() {
        System.out.println("El experimento se replica mediante protocolo.");
    }

}
