package baseespacial;

public class BaseEspacial {

    public static void main(String[] args) {

        System.out.println("Sistema de Unidades Operativas");

        Base base = new Base();

        try {
            Astronauta capitan = new Astronauta(15, "Juan", "Nave", TipoAtmofera.VACIO);
            Astronauta sargento = new Astronauta(15, "Roberto", "Nave", TipoAtmofera.VACIO);
            Robot ayudante = new Robot(10, "Rd2", "Cocina", TipoAtmofera.PRESURIZADA);
            Robot doblador = new Robot(10, "Bender", "Fabrica", TipoAtmofera.PRESURIZADA);
            Experimento laser = new Experimento(5, "Laser", "Nave", TipoAtmofera.VACIO);
            Experimento mutante = new Experimento(5, "prueba", "Laboratorio", TipoAtmofera.VACIO);

            base.agregarUnidadOperativa(capitan);
            base.agregarUnidadOperativa(sargento);
            base.agregarUnidadOperativa(ayudante);
            base.agregarUnidadOperativa(doblador);
            base.agregarUnidadOperativa(laser);
            base.agregarUnidadOperativa(mutante);

            base.mostrarUnidades();
            base.mover();
            base.filtrarPorTipoAtmofera(TipoAtmofera.VACIO);
            base.realizarFuncionesBasicas();

        } catch (MismoNombreYModuloException e) {
            System.out.println(e.getMessage());
        }
    }

}
