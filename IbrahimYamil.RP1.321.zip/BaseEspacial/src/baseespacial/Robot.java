
package baseespacial;

public class Robot extends UnidadOperativa implements Movible{
    private int autonomiaOperativa ; 

    public Robot(int autonomiaOperativa, String nombre, String modulo, TipoAtmofera tipoatmofera) {
        super(nombre, modulo, tipoatmofera);
        this.autonomiaOperativa = autonomiaOperativa;
    }
    
    @Override
    public void mover (){
        System.out.println("Soy "+ this.getNombre() + " soy un "+ this.getClass().getSimpleName() + " y me muevo");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());
        sb.append("-autonomia Operativa = ").append(autonomiaOperativa);
        
        return sb.toString();
    }

    @Override
    public void reabastecerse() {
        System.out.println("Robot se reabastece");
    }

    @Override
    public void mantenerCondicionAtmoferica() {
        System.out.println("Robot mantiene las condiciones atmosfericas");
    }

    @Override
    public void replicarse() {
        System.out.println("Robot se replica mendiante copia");
    }
    
    
    
}
