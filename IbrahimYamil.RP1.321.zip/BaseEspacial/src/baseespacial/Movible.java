package baseespacial;

public interface Movible {

    void mover();

}
