package baseespacial;

import java.util.Objects;

public abstract class UnidadOperativa implements FuncionesBasicas {

    private String nombre;
    private String modulo;
    private TipoAtmofera tipoatmofera;

    public UnidadOperativa(String nombre, String modulo, TipoAtmofera tipoatmofera) {
        this.nombre = nombre;
        this.modulo = modulo;
        this.tipoatmofera = tipoatmofera;
    }

    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoAtmofera getTipoatmofera() {
        return tipoatmofera;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.nombre);
        hash = 29 * hash + Objects.hashCode(this.modulo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UnidadOperativa other = (UnidadOperativa) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return Objects.equals(this.modulo, other.modulo);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(System.lineSeparator());
        sb.append("-nombre = ").append(nombre);
        sb.append(System.lineSeparator());
        sb.append("-modulo = ").append(modulo);
        sb.append(System.lineSeparator());
        sb.append("-tipoatmofera = ").append(tipoatmofera);

        return sb.toString();
    }

}
