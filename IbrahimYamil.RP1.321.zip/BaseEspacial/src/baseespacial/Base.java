package baseespacial;

import java.util.ArrayList;

public class Base {

    private ArrayList<UnidadOperativa> lista;

    public Base() {
        this.lista = new ArrayList();
    }

    public void agregarUnidadOperativa(UnidadOperativa e) {

        if (this.lista.contains(e)) {
            throw new MismoNombreYModuloException("La unidad operativa " + e.getNombre() + " ya se encuentra en la lista");
        }
        this.lista.add(e);
        System.out.println("Unidad agregada correctamente");
    }

    public void mostrarUnidades() {
        System.out.println("Unidades Operativas");
        System.out.println("----------");
        System.out.println("Cantidad: " + this.lista.size());

        for (UnidadOperativa e : this.lista) {
            System.out.println(e);
            System.out.println("----------");
        }
    }

    public void mover() {

        System.out.println("Unidades que se mueven");

        for (UnidadOperativa e : this.lista) {

            if (e != null) {
                if (e instanceof Movible mover) {
                    mover.mover();
                } else {
                    System.out.println(e.getNombre() + " no se puede mover");
                }
            }
        }
    }

    public void filtrarPorTipoAtmofera(TipoAtmofera tipo) {
        System.out.println("Unidades filtradas por tipo de atmofera: " + tipo);
        for (UnidadOperativa e : this.lista) {
            if (e.getTipoatmofera().equals(tipo)) {
                System.out.println(e);
            }
        }
    }

    public void realizarFuncionesBasicas() {
        for (UnidadOperativa e : this.lista) {
            if (e instanceof FuncionesBasicas unidad) {
                unidad.replicarse();
                unidad.mantenerCondicionAtmoferica();
                unidad.reabastecerse();
            }
        }
    }
}
