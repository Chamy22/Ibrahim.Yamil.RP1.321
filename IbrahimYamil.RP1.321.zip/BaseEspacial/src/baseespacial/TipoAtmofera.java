package baseespacial;

public enum TipoAtmofera {
    PRESURIZADA,
    VACIO;

}
