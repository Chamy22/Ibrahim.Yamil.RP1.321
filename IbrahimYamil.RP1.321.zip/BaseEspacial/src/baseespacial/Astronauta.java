package baseespacial;

public class Astronauta extends UnidadOperativa implements Movible {

    private int cantidadMaxAct;

    public Astronauta(int cantidadMaxAct, String nombre, String modulo, TipoAtmofera tipoatmofera) {
        super(nombre, modulo, tipoatmofera);
        this.cantidadMaxAct = cantidadMaxAct;
    }

    @Override
    public void mover() {
        System.out.println("Soy " + this.getNombre() + " soy un " + this.getClass().getSimpleName() + " y me muevo ");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());
        sb.append("-cantidad Max Actividad = ").append(cantidadMaxAct);
        sb.append(System.lineSeparator());

        return sb.toString();
    }

    @Override
    public void reabastecerse() {
        System.out.println("Astronauta se reabastece.");
    }

    @Override
    public void mantenerCondicionAtmoferica() {
        System.out.println("Astronauta mantiene las condiciones atmosfericas.");
    }

    @Override
    public void replicarse() {
        System.out.println("Astronauta se replica mediante entrenamiento.");
    }

}
