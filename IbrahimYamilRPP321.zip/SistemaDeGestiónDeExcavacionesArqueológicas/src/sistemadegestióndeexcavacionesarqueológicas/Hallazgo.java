
package sistemadegestióndeexcavacionesarqueológicas;

import java.time.LocalDate;
import java.util.Objects;

public class Hallazgo {
    
    private int id;
    private String sitio;
    private LocalDate fecha;
    private int estadoConservacion ; 
    private EpocaHistorica epocaHistorica; 



    public Hallazgo(int id, String sitio, LocalDate fecha, int estadoConservacion, EpocaHistorica epocaHistorica) {
        this.id = id;
        this.sitio = sitio;
        this.fecha = fecha;
        this.estadoConservacion = estadoConservacion;
        this.epocaHistorica = epocaHistorica;
    }

    public int getId() {
        return id;
    }

    public String getSitio() {
        return sitio;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }

    public EpocaHistorica getEpocaHistorica() {
        return epocaHistorica;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.sitio);
        hash = 89 * hash + Objects.hashCode(this.fecha);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hallazgo other = (Hallazgo) obj;
        if (!Objects.equals(this.sitio, other.sitio)) {
            return false;
        }
        return Objects.equals(this.fecha, other.fecha);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(System.lineSeparator());
        sb.append("Hallazgo{");
        sb.append(System.lineSeparator());        
        sb.append("id=").append(id);
        sb.append(System.lineSeparator());
        sb.append("-sitio = ").append(sitio);
        sb.append(System.lineSeparator());
        sb.append("-fecha = ").append(fecha);
        sb.append(System.lineSeparator());
        sb.append("-estado de Conservacion = ").append(estadoConservacion);
        sb.append(System.lineSeparator());
        sb.append("-epoca Historica = ").append(epocaHistorica);

        return sb.toString();
    }
    
    
    
    
    
    
}
