
package sistemadegestióndeexcavacionesarqueológicas;

public class HallazgoDuplicadoException extends RuntimeException {

    public HallazgoDuplicadoException() {
    }

    public HallazgoDuplicadoException(String message) {
        super(message);
    }

    
}
