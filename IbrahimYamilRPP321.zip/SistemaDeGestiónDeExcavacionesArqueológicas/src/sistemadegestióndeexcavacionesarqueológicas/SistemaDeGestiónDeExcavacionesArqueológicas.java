
package sistemadegestióndeexcavacionesarqueológicas;

import java.time.LocalDate;

public class SistemaDeGestiónDeExcavacionesArqueológicas {

    public static void main(String[] args) {
        
        System.out.println("Sistema de Gestion de Excavaciones Arqueologicas");
       
        GestorHallazgo hallazgos = new GestorHallazgo();
        
        try {
             Fosil dinosaurio = new Fosil ("Sitio A", true, 0, "Montania", LocalDate.EPOCH, 0, EpocaHistorica.PRECOLOMBINA);
             Fosil rex = new Fosil ("Sitio A", false, 0, "Suelo", LocalDate.EPOCH, 5, EpocaHistorica.COLONIAL);

            
            hallazgos.registrarHallazgo(dinosaurio);
            hallazgos.registrarHallazgo(rex);
        }
        
        //hallazgos.listarHallazgos();
        //hallazgos.filtrarPorEpocaHistorica(EpocaHistorica.COLONIAL);
        catch (HallazgoDuplicadoException nuevo){
            System.out.println(nuevo.getMessage());
        }
        
        //hallazgos.listarHallazgos();
    }
    
   
    
}
