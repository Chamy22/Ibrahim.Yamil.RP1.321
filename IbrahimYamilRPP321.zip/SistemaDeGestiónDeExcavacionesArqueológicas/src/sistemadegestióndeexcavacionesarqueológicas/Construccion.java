
package sistemadegestióndeexcavacionesarqueológicas;

import java.time.LocalDate;

public class Construccion extends Hallazgo implements Restaurable {
    private String tipoEdificacion; 
    private EpocaHistorica epocaHistorica;

    public Construccion(String tipoEdificacion, int id, String sitio, LocalDate fecha, int estadoConservacion, EpocaHistorica epocaHistorica) {
        super(id, sitio, fecha, estadoConservacion, epocaHistorica);
        this.tipoEdificacion = tipoEdificacion;
        this.epocaHistorica = epocaHistorica;
    }
    

    @Override
    public void restaurar() {
        System.out.println("Soy " + this.getClass().getSimpleName() + " y me pueden restaurar");
    }   

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());        
        sb.append("-tipo Edificacion = ").append(tipoEdificacion);
        sb.append(System.lineSeparator());
        sb.append("-epocaHistorica = ").append(epocaHistorica);

        return sb.toString();
    }
    
    
    
}
