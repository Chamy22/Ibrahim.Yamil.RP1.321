
package sistemadegestióndeexcavacionesarqueológicas;

import java.util.ArrayList;

public class GestorHallazgo {
    
    private ArrayList<Hallazgo> hallazgos;
    
    public GestorHallazgo (){
        this.hallazgos = new ArrayList ();
    }
    
    public void registrarHallazgo(Hallazgo nuevo) {
        if ( this.hallazgos.contains(nuevo)){
            throw new HallazgoDuplicadoException("El registro " + nuevo.getSitio() + " ya se encuentra registrada");
        }
        this.hallazgos.add (nuevo);
        System.out.println("Registro Exitoso");
    }
    
        public void listarHallazgos() {
        System.out.println("Hallazgos registrados");
        System.out.println("----------");
        System.out.println("Cantidad: " + this.hallazgos.size());            

        for (Hallazgo nuevo : this.hallazgos) {
            System.out.println(nuevo);
            System.out.println("----------");        
        }
    }

    public void analizar() {

        System.out.println("Unidades se pueden analizar");

        for (Hallazgo nuevo : this.hallazgos) {

            if (nuevo != null) {
                if (nuevo instanceof Analizable analizar) {
                    analizar.analizar();
                } else {
                    System.out.println(nuevo.getClass().getSimpleName()+ " no se puede analizar");
                }
            }
        }
    } 
    public void restaurar() {

        System.out.println("Unidades se pueden Restaurar");

        for (Hallazgo nuevo : this.hallazgos) {

            if (nuevo != null) {
                if (nuevo instanceof Restaurable restaurar) {
                    restaurar.restaurar();
                } else {
                    System.out.println(nuevo.getClass().getSimpleName()+ " no se puede restaurar");
                }
            }
        }
    } 
    
        public void filtrarPorEpocaHistorica(EpocaHistorica tipo) {
        System.out.println("Unidades filtradas por la epoca historica: " + tipo);
        for (Hallazgo nuevo : this.hallazgos) {
            if (nuevo.getEpocaHistorica().equals(tipo)) {
                System.out.println(nuevo);
            }
        }
    }
    
    
}
