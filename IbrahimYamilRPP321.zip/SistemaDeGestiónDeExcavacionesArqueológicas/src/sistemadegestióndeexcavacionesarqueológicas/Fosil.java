
package sistemadegestióndeexcavacionesarqueológicas;

import java.time.LocalDate;

public class Fosil extends Hallazgo implements Analizable {
    private String especie;
    private boolean esqueletoCompleto;

    public Fosil(String especie, boolean esqueletoCompleto, int id, String sitio, LocalDate fecha, int estadoConservacion, EpocaHistorica epocaHistorica) {
        super(id, sitio, fecha, estadoConservacion, epocaHistorica);
        this.especie = especie;
        this.esqueletoCompleto = esqueletoCompleto;
    }

    @Override
    public void analizar() {
        System.out.println("Soy " + this.getClass().getSimpleName() + " y me pueden analizar");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());
        sb.append("-especie = ").append(especie);
        sb.append(System.lineSeparator());
        sb.append("-esqueleto Completo = ").append(esqueletoCompleto);

        return sb.toString();
    }
    
    
    
    
}
