
package sistemadegestióndeexcavacionesarqueológicas;

import java.time.LocalDate;

public class Herramienta extends Hallazgo implements Analizable {
    private String material;
    private String usoProbable;

    public Herramienta(String material, String usoProbable, int id, String sitio, LocalDate fecha, int estadoConservacion, EpocaHistorica epocaHistorica) {
        super(id, sitio, fecha, estadoConservacion, epocaHistorica);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    @Override
    public void analizar() {
        System.out.println("Soy " + this.getClass().getSimpleName() + " y me pueden analizar");
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(System.lineSeparator());        
        sb.append("-material = ").append(material);
        sb.append(System.lineSeparator());
        sb.append("-usoProbable = ").append(usoProbable);

        return sb.toString();
    }
    
    
}
